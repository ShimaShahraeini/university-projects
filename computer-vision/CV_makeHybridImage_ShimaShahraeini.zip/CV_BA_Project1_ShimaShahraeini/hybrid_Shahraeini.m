clc;
clear;
close all;

im1 = imread('BrownEye.jpg');
im2 = imread('theSunflower.jpg');

gray_im1 = rgb2gray(im1);
gray_im2 = rgb2gray(im2);

gray_im1 = im2double(gray_im1);
gray_im2 = im2double(gray_im2);

im1_gauss = imgaussfilt(gray_im1,20);
im2_gauss = imgaussfilt(gray_im2,10);

im2_laplas = gray_im2 - im2_gauss;

hybrid_im = imadd(im2_laplas,im1_gauss);

figure(1);
imshowpair(im2,im1,'montage');
figure(2);
imshowpair(im2_laplas,im1_gauss,'montage');

figure(3)
imshow(hybrid_im);
title("hybrid image (eye+sunflower)");
