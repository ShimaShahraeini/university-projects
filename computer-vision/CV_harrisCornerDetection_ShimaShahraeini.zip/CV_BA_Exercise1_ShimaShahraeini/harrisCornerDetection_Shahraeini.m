clc;
clear;
close all;

image_path = "corner.jfif";
k = 0.06; % Sensitivity factor (commonly between 0.04 to 0.06)
threshold = 100000; % Define the threshold

% Read image
I = imread(image_path);
image = I;

if size(I, 3) == 3
    I = rgb2gray(I);
end
I = double(I);

% Sobel filters for gradient computation
Gx = [-1 0 1; -1 0 1; -1 0 1];
Gy = Gx';

% Compute x and y derivatives of the image
Ix = conv2(I, Gx, 'same');
Iy = conv2(I, Gy, 'same');

% Compute products of derivatives
Ixx = Ix.^2;
Iyy = Iy.^2;
Ixy = Ix.*Iy;

% Gaussian filter for smoothing
g = fspecial('gaussian',[7 7],2);
Ixx = conv2(Ixx, g, 'same');
Iyy = conv2(Iyy, g, 'same');
Ixy = conv2(Ixy, g, 'same');

% Harris corner measure
%R = det(H) - k(trace(H))^2
R = (Ixx.*Iyy - Ixy.^2) - k*(Ixx + Iyy).^2;

% Thresholding
R(R < threshold) = 0;

% Non-maximum suppression
corners = imregionalmax(R);

% Display
[rows, cols] = find(corners);
imshow(image, []); 
hold on;
plot(cols, rows, 'ys');